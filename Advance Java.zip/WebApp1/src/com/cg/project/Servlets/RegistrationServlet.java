package com.cg.project.Servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sun.rmi.server.Dispatcher;

import com.cg.project.beans.Associate;

@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try{
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		long mobileNo=Long.parseLong(request.getParameter("mobileNo"));
		String emailId=request.getParameter("emailId");
		int age=Integer.parseInt(request.getParameter("age"));
		String[] hobbies=request.getParameterValues("hobbies");
		Date dateOfBirth=(Date)new SimpleDateFormat("yyyy-mm-dd").parse(request.getParameter("dateOfBirth"));
		String qualification=request.getParameter("qualification");
		String address=request.getParameter("address");
		int pinCode=Integer.parseInt(request.getParameter("pinCode"));
		String city=request.getParameter("city");
		Associate associate = new Associate(firstName, lastName, department, designation, mobileNo,emailId, age, hobbies, dateOfBirth, qualification, address, pinCode, city);
		RequestDispatcher dispatcher = request.getRequestDispatcher("RegistrationSuccessPage.jsp");
		request.setAttribute("associate",associate);
		dispatcher.forward(request, response);
		}
		catch(ParseException e){

	}
}
}
