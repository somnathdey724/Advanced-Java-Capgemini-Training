package com.cg.project.client;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.project.beans.Associate;
import com.cg.project.beans.BankDetail;
import com.cg.project.beans.Salary;
import com.cg.project.daoservices.AssociateDAO;
import com.cg.project.daoservices.AssociateDAOImpl;
public class MainClass {
	public static void main(String[] args) {
		AssociateDAO dao = new AssociateDAOImpl();
		Associate associate= new Associate(15000, "Somnath", "Dey", "HR", "Sr. analyst", "CBCJ14SD", "som@gmail.com", new BankDetail(123456, "ICICI", "icici0002"), new Salary(18000, 1000, 1000));
		dao.save(associate);
		ArrayList<Associate> list=dao.findsAll();
		for (Associate associate2 : list) {
			System.out.println(associate2);
		}
		/*		dao.save(associate);
		Associate associate2=new Associate("Ankur", "Kadsare", "ak@gmail.com", "HR");
		dao.update(dao.findOne(1));
		ArrayList<Associate> list=dao.findsAll();
		for (Associate associate3 : list) {
			System.out.println(associate3);
		}
		Associate associate2=dao.findOne(1);
		System.out.println(associate2);*/
	}
}
