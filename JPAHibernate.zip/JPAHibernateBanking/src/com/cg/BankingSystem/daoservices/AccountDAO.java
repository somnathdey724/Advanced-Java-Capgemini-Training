package com.cg.BankingSystem.daoservices;

import java.sql.SQLException;
import java.util.List;

import com.cg.BankingSystem.Exceptions.BankingServicesDownException;
import com.cg.BankingSystem.beans.Account;
import com.cg.BankingSystem.beans.Transaction;

public interface AccountDAO {
	Account save(Account account) throws SQLException;
	Account findOne(long accountNo) throws SQLException;
	boolean update(Account account) throws SQLException;
	List<Account> findAll() throws SQLException;
	boolean  addTransaction(Transaction transaction)throws SQLException, BankingServicesDownException;
	List<Transaction> getAllTransaction(long accountNo)throws SQLException;
}
