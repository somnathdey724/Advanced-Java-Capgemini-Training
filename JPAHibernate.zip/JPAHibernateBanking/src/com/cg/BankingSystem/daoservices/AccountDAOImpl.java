package com.cg.BankingSystem.daoservices;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import com.cg.BankingSystem.Exceptions.BankingServicesDownException;
import com.cg.BankingSystem.beans.Account;
import com.cg.BankingSystem.beans.Transaction;
import com.cg.BankingSystem.util.EntityManagerFactoryProvider;
public class AccountDAOImpl implements AccountDAO{
EntityManagerFactory factory=EntityManagerFactoryProvider.getEntityManagerFactory();
	@Override
	public Account save(Account account) throws SQLException {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		account.setPinNumber((int)Math.random()*9000+1000);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}
	@Override
	public Account findOne(long accountNo) throws SQLException {
		EntityManager entityManager = factory.createEntityManager();
		return entityManager.find(Account.class, accountNo);
	}
	@Override
	public boolean update(Account account) throws SQLException {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}
	@Override
	public List<Account> findAll() throws SQLException {
		EntityManager entityManager=factory.createEntityManager();
		Query query=entityManager.createQuery("from Account a");
		@SuppressWarnings("unchecked")
		ArrayList<Account> list=(ArrayList<Account>)query.getResultList();
		return list;
	}
	@Override
	public boolean addTransaction(Transaction transaction) throws SQLException, BankingServicesDownException {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return false;
	}
	@Override
	public List<Transaction> getAllTransaction(long accountNo)
			throws SQLException {
		EntityManager entityManager=factory.createEntityManager();
		Query query=entityManager.createQuery("from Transaction t");
		@SuppressWarnings("unchecked")
		ArrayList<Transaction> list=(ArrayList<Transaction>)query.getResultList();
		return list;
	}
}
