package com.cg.BankingSystem.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.BankingSystem.Exceptions.AccountBlockedException;
import com.cg.BankingSystem.Exceptions.AccountNotFoundException;
import com.cg.BankingSystem.Exceptions.BankingServicesDownException;
import com.cg.BankingSystem.Exceptions.InsufficientAmountException;
import com.cg.BankingSystem.Exceptions.InvalidAccountTypeException;
import com.cg.BankingSystem.Exceptions.InvalidAmountException;
import com.cg.BankingSystem.Exceptions.InvalidPinNumberException;
import com.cg.BankingSystem.beans.Account;
import com.cg.BankingSystem.beans.Transaction;
import com.cg.BankingSystem.daoservices.AccountDAO;
import com.cg.BankingSystem.daoservices.AccountDAOImpl;

public class BankingServicesImpl implements BankingServices{
	AccountDAO accountDao = new AccountDAOImpl();	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException,
			BankingServicesDownException, SQLException {
		Account account = new Account(accountType, initBalance);
		account=accountDao.save(account);
		return account.getAccountNo();
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException,
			AccountBlockedException, SQLException {
		Account account=accountDao.findOne(accountNo);
		account.setAccountBalance(amount+account.getAccountBalance());
		Transaction transaction = new Transaction(amount, "Credited", new Account(accountNo));
		accountDao.addTransaction(transaction);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException, InvalidAmountException {
		Account account=accountDao.findOne(accountNo);
		if(pinNumber==account.getPinNumber())
			if(amount<account.getAccountBalance())
			return account.getAccountBalance()-amount;
		else
			throw new InvalidAmountException();
		else
			throw new InvalidPinNumberException();
		
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException {
		Account accountTo=accountDao.findOne(accountNoTo);
		Account accountFrom=accountDao.findOne(accountNoFrom);
		if(pinNumber==accountFrom.getPinNumber())
			if(transferAmount<accountFrom.getAccountBalance())
				return true;
			else
				throw new InsufficientAmountException();
		else
			throw new InvalidPinNumberException();
	}

	@Override
	public Account getAccountDetails(long accountNo)
			throws AccountNotFoundException, BankingServicesDownException, SQLException {
		Account account=accountDao.findOne(accountNo);
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails()
			throws BankingServicesDownException, SQLException {
		List<Account> list = accountDao.findAll();
		return list;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, SQLException {
		List<Transaction> list=accountDao.getAllTransaction(accountNo);
		return list;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException,
			AccountBlockedException, SQLException {
		Account account=accountDao.findOne(accountNo);
		if(account!=null)
			return "Active";
		else
			return "Inactive";
		
	}

}
